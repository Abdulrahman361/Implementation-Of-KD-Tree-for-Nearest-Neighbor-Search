""" Assignment 2: KD Trees

=== EECS1516 Winter 2024 ===

=== Module Description ===
This module contains the following classes:

- TreeReader: a class that reads the tree data from a csv file.  This contains
a static method that returns a list of MunicipalTree objects.  A static method
is a method that does not require an instance of the class to be called.
- KDTree: a class that represents a KDTree, which is used to store the trees in the
dataset and to find the nearest tree to a given location. A KD Tree is a binary search tree
(BST) structure designed for efficiently organizing and searching multidimensional points
in space. The 'K' in KD Tree refers to the number of dimensions in the space. The
BST recursively divides the space along alternating axes, creating a hierarchical
structure that facilitates quick search operations, especially for nearest neighbor queries.
This data structure is commonly employed in computational geometry, machine learning, and computer
graphics.
- MunicipalTree: a class that represents a tree in the dataset.
- MapView: a class that visualizes the trees in the dataset on a map. It also handles
mouse clicks on the map. It contains a reference to a KDTree so that it
can efficiently query the tree for the nearest tree to a mouse click.

Like your lab 4, the module also illustrates a Model-View-Controller (MVC) software design.
The KDTree class is a data model and the MapView class is the data view.
"""
from __future__ import annotations
from kdtree import KDTree  # for building the KDTree
from tree_utilities import MunicipalTree  # for representing the trees in the dataset

import math  # for mathematical operations
import matplotlib.pyplot as plt  # for plotting
import matplotlib.image as mpimg
from matplotlib.backend_bases import PickEvent  # for handling mouse clicks


class MapView:
    """A map view of the trees in the dataset. The map view is responsible for
    drawing the map and the data on the map. It also handles mouse clicks on the map.
    """

    def __init__(self, kdtree: KDTree, treedata: list[MunicipalTree]) -> None:
        """Initialize a new map view. The map view is responsible for drawing
        the map and the data on the map. It also handles mouse clicks on the map.
        It contains a reference to the KDTree so that it can query the KDTree for
        the data point nearest to a mouse click.
        Attributes:
        _h: height of the map
        _w: width of the map
        _urx: upper right x coordinate of the map
        _ury: upper right y coordinate of the map
        _llx: lower left x coordinate of the map
        _lly: lower left y coordinate of the map
        _fig: the figure
        _ax: the axes
        _treelist: the list of trees to be visualized
        _kdtree: the kdtree, which facilitates nearest neighbor queries
        """
        self._h, self._w = 300, 670  # dimensions of the map
        self._urx, self._ury = 43.781322, -79.533667  # coordinate boundaries of the map
        self._llx, self._lly = 43.745431, -79.424748
        self._fig = None
        self._ax = None
        self._kdtree = kdtree  # the kdtree, which facilitates nearest neighbor queries
        self._treedata = treedata  # the list of trees

    def on_pick(self, event: PickEvent):
        """Handle a mouse click event on the map. This method will find the
        nearest item of data to the mouse click by calling the get_nearest method
        of the KD Tree. It will then draw a circle around that data point on the map."""
        xmouse, ymouse = event.mouseevent.xdata, event.mouseevent.ydata
        lon = self._lly + ((self._ury - self._lly) * (self._w - xmouse) / self._w)
        lat = self._llx + ((self._urx - self._llx) * (self._h - ymouse) / self._h)

        nearest = self._kdtree.get_nearest(lat, lon)
        print("\nThe nearest Municipal Tree is a:\n" + str(nearest))

        self.draw_trees([nearest], 'co')
        self._fig.canvas.draw()

    def draw(self):
        """Draw the map and the data on the map. This method will not return
        until the user has closed the map window."""
        self._fig, self._ax = plt.subplots()
        self.draw_map()
        self._fig.canvas.draw()
        self.draw_trees(self._treedata)
        self._fig.canvas.mpl_connect('pick_event', self.on_pick)
        plt.title('Municipal Trees in Toronto')
        plt.show()

    def draw_trees(self, trees: list[MunicipalTree], color='ro'):
        """Helper method for draw; draws the trees on the map."""
        ylim = self._ax.get_ylim()
        xlim = self._ax.get_xlim()
        self._h = math.floor(max(ylim))
        self._w = math.floor(max(xlim))

        # locate only the trees in the boundaries of the map
        filtered_trees = list(
            filter(lambda x: self._lly >= float(x._lon) >= self._ury and self._urx >= float(x._lat) >= self._llx,
                   trees))
        xvalues = list(
            map(lambda x: self._w - self._w * ((float(x._lon) - self._lly) / (self._ury - self._lly)), filtered_trees))
        yvalues = list(
            map(lambda x: self._h - self._h * ((float(x._lat) - self._llx) / (self._urx - self._llx)), filtered_trees))

        # draw the trees
        self._ax.plot(xvalues, yvalues, color, picker=True)

    def draw_map(self):
        """Helper method for draw; draws the map."""
        img = mpimg.imread('york.png')  # read the map image
        self._ax.imshow(img)
        self._ax.autoscale(False)

