from __future__ import annotations
import csv
import math  # you will need this to calculate distances!


class MunicipalTree:
    """A municipal tree
    === Attributes ===
    _id: The id of the tree
    _ward: The ward responsible for the tree
    _species: The species of the tree
    _diameter: The diameter of the tree
    _lon: longitude
    _lat: latitude
    """
    _id: int
    _ward: int
    _species: str
    _diameter: int
    _lon: float
    _lat: float

    def __init__(self, id: str, ward: str, species: str, diameter: str, lon: str, lat: str) -> None:
        """Initialize a new tree.
        If the id, ward, or diameter is an empty string, it will be set to -1.
        If the lon or lat is an empty string, it will be set to 0.0.
    >>> tree = MunicipalTree('1', '1', 'oak', '10', '1', '1')
    >>> isinstance(tree._id, int)
    True
    >>> isinstance(tree._ward, int)
    True
    >>> isinstance(tree._lon, float)
    True
    """
        self._id = int(id) if id else -1
        self._ward = int(ward) if ward else -1
        self._species = species
        self._diameter = int(diameter) if diameter else -1
        self._lon = float(lon) if lon else 0.0
        self._lat = float(lat) if lat else 0.0
        # self._id = int(id) 
        # self._ward = int(ward) 
        # self._species = species
        # self._diameter = int(diameter) 
        # self._lon = float(lon)
        # self._lat = float(lat) 

    def __str__(self) -> str:
        """ Return a string representation of this tree.
        Format: <species> at (<longitude>, <latitude>) with diameter <diameter>
        """
        a = round(float(self._lat), 3)
        b = round(float(self._lon), 3)
        return f'{self._species} at ({a}, {b}) with diameter {self._diameter}'

    @property
    def lon(self) -> float:
        return self._lon

    @property
    def lat(self) -> float:
        return self._lat

    @property
    def species(self) -> str:
        return self._species

    def distance_to(self, lon: float, lat: float) -> float:
        """Return the distance from this tree to the given coordinates.
        Calculate the distance using the Euclidean distance formula,
        and round the result to 5 decimal places.
        >>> tree = MunicipalTree('1', '1', 'oak', '10', '1', '1')
        >>> tree.distance_to(1, 1)
        0.0
        >>> tree.distance_to(2, 2)
        1.41421
        >>> tree.distance_to(3, 3)
        2.82843
        >>> tree = MunicipalTree('5216', '1', 'Yew', '1', '-79.551765', '43.724121')
        >>> tree.distance_to(-79.551765, 43.724121)
        0.0
        >>> tree.distance_to(-79.551865, 43.724221)
        0.00014
        >>> tree.distance_to(-79.554, 43.726)
        0.00292
    
        """
    
        # distance = math.sqrt((self._lat - lat) ** 2 + (self._lon - lon) ** 2)
        # return round(distance, 5)
    
    # Convert latitude and longitude to floats
        tree_lat = float(self._lat)
        tree_lon = float(self._lon)

        # Calculate distance using the Euclidean distance formula
        distance = math.sqrt((lat - tree_lat) ** 2 + (lon - tree_lon) ** 2)
        
        # Round the result to 5 decimal places
        return round(distance, 5)


class TreeReader:
    """A class to read the tree data from a csv file.
    We will use static methods to read the data,
    so there will be no need to create an instance of
    this class."""

    @staticmethod  # static! We do not need an instance of this class to use this method.
    def read_trees(filename: str) -> list[MunicipalTree]:
        """Read the tree data from the csv file and return a
        list of trees."""
        trees = []

        with open(filename, newline='') as csvfile:
            treereader = csv.reader(csvfile, delimiter=',')
            count = 0
            for row in treereader:
                if count > 0:
                    trees.append(MunicipalTree(*row))
                count += 1

        return trees


if __name__ == '__main__':
    # You can use this to test this portion of your code.
    import doctest
    doctest.testmod()
    trees = TreeReader.read_trees('york_treelist.csv')
    tree=MunicipalTree( '', '', '', '', '', '')
