from kdtree import KDTree, _KDTNode
from map_view import MapView
from tree_utilities import TreeReader
import pickle  # for test cases in doctests

# This code simply serves as an example of how to use the KDTree and MapView classes
# to create an interactive map of the trees in the treelist.
if __name__ == "__main__":

    print("Below is an example of a KD Tree:")
    with open('kdtree.pkl', 'rb') as file:
        loaded_object = pickle.load(file)
        loaded_object.display_tree()

    treelist = TreeReader.read_trees("york_treelist.csv")
    print("Read " + str(len(treelist)) + " trees from file.")

    kdtree = KDTree(treelist)  # build the tree from the treelist
    print("Built a KD tree.")

    # create an interactive map of the trees that allows the
    # user to click the information about the tree nearest to the click
    treeView = MapView(kdtree, treelist)
    treeView.draw()